import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-diversion-certificate',
  templateUrl: './diversion-certificate.component.html',
  styleUrls: ['./diversion-certificate.component.css']
})
export class DiversionCertificateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
