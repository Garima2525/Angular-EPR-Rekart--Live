import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collection-disposal-certificate',
  templateUrl: './collection-disposal-certificate.component.html',
  styleUrls: ['./collection-disposal-certificate.component.css']
})
export class CollectionDisposalCertificateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
