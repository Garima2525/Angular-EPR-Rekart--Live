import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disposal-certificate',
  templateUrl: './disposal-certificate.component.html',
  styleUrls: ['./disposal-certificate.component.css']
})
export class DisposalCertificateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
