import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-disposal',
  templateUrl: './c-disposal.component.html',
  styleUrls: ['./c-disposal.component.css']
})
export class CDisposalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
