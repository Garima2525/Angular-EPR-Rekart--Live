import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-target-list',
  templateUrl: './target-list.component.html',
  styleUrls: ['./target-list.component.css']
})
export class TargetListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
