import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http: HttpClient) {}
  base_url = 'http://localhost:3159/epr';

  createUser(data: any) {
    let api_url = this.base_url + '/user';
    const httpOptions = {
      headers: new HttpHeaders({
        'content-type': 'application/json;charset=UTF-8',
        apikey: 'BCB930X-R1C4N46-GSFB2K7-KEKRKS2',
      }),
    };
    return this.http.post(api_url, data, httpOptions);
  }
}
